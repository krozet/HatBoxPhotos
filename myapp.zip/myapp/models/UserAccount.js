/*
 * Test collection for registered user accounts.
 *
 * USER DATABASE LAYOUT
 * Collection: Registered users
 * Document: User account
 * Fields: See login credentials schema
 */

// Import mongoose and bcrypt dependencies.
// Mongoose to map MongoDB database.
// Bcrypt for hashing and salting password.
var mongoose = require('mongoose');
var bcrypt = require('bcrypt');

// Login credentials schema
// This schema defines the fields in user account documents
var LoginCredentialsSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true,
        trim: true
    },
    username: {
        type: String,
        unique: true,
        required: true,
        trim: true,
        minlength: [2, 'Username must be at least 2 characters long'],
        maxlength: [20, 'Username must be less than 20 characters long']
        //_userID: LoginCredentialsSchema.Types.ObjectID
    },
    password: {
        type: String,
        required: true,
        minlength: [3, 'Password must be at least 3 characters long'],
        maxlength: [20, 'Password must be less than 20 characters long']
    }
});

// Authenticate input against database
LoginCredentialsSchema.statics.authenticate = function (username, password, callback) {
    RegisteredUser.findOne({ username: username }).exec(function (err, user) {
        if (err) {
            return callback(err);
        }
        else if (!user) {
            var err = new Error('User not found.');
            err.status = 401;
            return callback(err);
        }
        bcrypt.compare(password, user.password, function (err, result) {
            if (result === true) {
                return callback(null, user);
            }
            else {
                return callback();
            }
        });
    });
};

// Hashes password before saving it to the database
LoginCredentialsSchema.pre('save', function (next) {
    var user = this;
    bcrypt.hash(user.password, 10, function (err, hash) {
    if (err) {
      return next(err);
    }
    user.password = hash;
    next();
  });
});

// RegisteredUser models the RegisteredUser collection
// using LoginCredentialsSchema as UserAccount document fields.
//
/********************************IMPORTANT*************************************/
// The first argument in model() is the SINGULAR name of the collection
// the model is for. Mongoose automatically looks for the plural version
// of the model name. That's why the model is named RegisteredUser, without an s.
//
// See: http://mongoosejs.com/docs/models.html for more
var RegisteredUser = mongoose.model('RegisteredUser', LoginCredentialsSchema);

// Creates test user account document using create function.
// Similar format to the registration route in Router.js
// with these fields replacing the variable userData in Router.js
//
// RegisteredUser.create({
//     email: 'testemail@gmail.com',
//     username: 'testusername',
//     password: 'testpassword'},
//     function(err, small) {
//         if(err) console.log(err);
// });

module.exports = RegisteredUser;
