/*
 * Test collection for the image database.
 *
 * IMAGE DATABASE LAYOUT
 * Collection: Uploaded Images
 * Document: Image
 * Fields: See Image schema
 */

// Import mongoose dependency. Mongoose is used to map MongoDB database.
var mongoose = require('mongoose');

// Import mongoose-thumbnail plugin.
// This plugin adds a thumbnail field to a mongoose schema.
var mongoose_thumbnail = require('mongoose-thumbnail');

// Schema for Image documents. This is in a slightly different order
// from our DB organization section in the Milestone 2 document.
// We should update our document for consistency.
var UploadedImageSchema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    image_original: {type: Buffer, contentType: String},
    image_medium: {type: Buffer, contentType: String},
    image_medium_path: {type: String},
    image_thumbnail: {type: Buffer, contentType: String},
    image_thumbnail_path: {type: String},

    // PEOFESSOR RECOMMENDS CATEGORY BE A SEPARATE COLLECTION
    image_category: {type: String},
    image_file_name: {type: String},
    image_file_format: {type: String},

    // 1=accepted, 2=pending, 3=rejected
    status: {type: Number},

    // We can think of type Number as similar to int
    image_file_size: {type: Number },
    image_height: {type: Number},
    image_width: {type: Number},
    image_views: {type: Number},
    image_downloads: {type: Number},
    image_description: {type: String},
    uploaded_by: {type: String},
    upload_date: {type: Date},

    // will consist of key words in the image_description
    tags: [{type: String}]
});

/**
 * Adds image thumbnail field to the uploaded image schema.
 * Possibly replaces image_thumbnail field defined in schema above.
 *
 * Written following the JavaScript section of
 * https://www.npmjs.com/package/mongoose-thumbnail
 *
 * May have to write an additional post route similar to the one in the
 * using with express section
 *
 * UploadedImageSchema.plugin(mongoose_thumbnail, {
    name: "name,   // Sets name of thumbnail sub-field
    format: "jpg",              // Default thumbnail format is jpg
    size: 80,                   // Default thumbnail size is 96

    // if inline is true, the thumbnail is not saved to a file but
    // directly in the mongoose document, in the thumbnail sub-field,
    // encoded as a string using the Data URI scheme (defaults to false)
    inline: true
    });
 */


// UploadedImage models the UploadedImages collection
// using UploadedImageSchema as Image document fields.
//
// The first argument of model() is the singular name
// of the collection being modeled
var UploadedImage = mongoose.model('UploadedImage', UploadedImageSchema);

// UploadedImage.create({
//   _id: new mongoose.Types.ObjectId(),
//     image_file_name: 'dog',
//     image_src: 'https://www.publicdomainpictures.net/pictures/50000/velka/funny-dog-7-serie.jpg'},
//     function(err, small) {
//         if(err) console.log(err);
// });
//
// UploadedImage.create({
//     image_file_name: 'cat',
//     image_src: 'http://static.boredpanda.com/blog/wp-content/uploads/2014/01/funny-cats-sneezing-3.jpg'},
//     function(err, small) {
//         if(err) console.log(err);
// });
//
// UploadedImage.create({
//     image_file_name: 'frog',
//     image_src: 'http://www.desktopimages.org/pictures/2013/1114/1/funny-frog-on-rain-wallpaper-7095.jpg'},
//     function(err, small) {
//         if(err) console.log(err);
// });

module.exports = UploadedImage;
