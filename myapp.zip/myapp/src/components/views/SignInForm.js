/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import React, {Link} from 'react';
import { Button, Form, FormGroup, Label, Input} from 'reactstrap';

export default class SignInForm extends React.Component {
  render() {
    return (
        <div>
      <Form inline>
        <FormGroup className="mb-2 mr-sm-2 mb-sm-0">
          <Label for="exampleEmail" className="mr-sm-2">Email</Label>
          <Input type="email" name="email" id="exampleEmail" placeholder="example@gmail.com" />
        </FormGroup>
        <FormGroup className="mb-2 mr-sm-2 mb-sm-0">
          <Label for="examplePassword" className="mr-sm-2">Password</Label>
          <Input type="password" name="password" id="examplePassword" placeholder="Example123" />
        </FormGroup>
        <Button>Submit</Button>
       <a href="#">Forgot your password?</a>
      
      </Form>
      
      
      </div>
    );
  }
}
