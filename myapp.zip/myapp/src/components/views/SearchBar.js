/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import React from 'react';
import {withRouter} from 'react-router-dom';

import {
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupDropdown,
  Input,
  Button,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  FormGroup,
  Form,
  NavLink
 } from 'reactstrap';

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    
   
    this.toggleDropDown = this.toggleDropDown.bind(this);
    this.toggleSplit = this.toggleSplit.bind(this);
    this.state = {
      dropdownOpen: false,
      splitButtonOpen: false
    };

    this.updateSelectFromChild = this.updateSelectFromChild.bind(this);
    this.updateSearchFromChild = this.updateSearchFromChild.bind(this);
    this.updateSubmit = this.updateSubmit.bind(this);
    
  }


               // this.updateInput = this.updateInput.bind(this);
               // this.handleSearch = this.handleSearch.bind(this); 
        toggleDropDown() {
        this.setState({
        dropdownOpen: !this.state.dropdownOpen
        });
        }

        toggleSplit() {
        this.setState({
        splitButtonOpen: !this.state.splitButtonOpen
        });
        }
        /*       updateInput(event){
        this.setState({search: event.target.value}) 
        }

        handleSearch(event){

        console.log('Your input value is: ' + this.state.search)
                //send state to the server code
        }

  }*/
  updateSelectFromChild(event){
      console.log("updateSelectFromChild");
      console.log(event.target.value);
      this.props.onChangeSelectInput(event.target.value);
  }
  updateSearchFromChild(event){
    console.log("updateSearchFromChild");
    console.log(event.target.value);
      //this.props.onChangeSearchInput(event.target.value);
      this.props.onChangeSearchInput(event.target.value);
  }

  updateSubmit(event){
    console.log("updateSubmit");
      event.preventDefault();
      this.props.onSearchTermSubmit();
      console.log("updateSubmit2");
      this.props.history.push('/Search');
      
  }

  render() {
    return (


       <div>
        <InputGroup >
          <InputGroupButtonDropdown addonType="prepend" isOpen={this.state.splitButtonOpen} toggle={this.toggleSplit}>
          <Input type="select" name="select" id="exampleSelect" onChange ={this.updateSelectFromChild} >
           {/*  <option>Photos</option> */}
            <option>Nature</option>
            <option>Animal</option>
            <option>City</option>
            <option>Food</option>
            <option>Car</option>
            <option>Travel</option>
          </Input>
          </InputGroupButtonDropdown>
          <Input type = "search" name = "searchInput" id ="exampleSearch" placeholder="search images"  value ={this.state.searchInput} onChange = {this.updateSearchFromChild} style={this.props.initialState}/>
          <InputGroupAddon addonType="append"><Button color="primary" onClick= {this.updateSubmit} >Search</Button></InputGroupAddon>
        </InputGroup>
      </div>

    );
  }
}


export default withRouter(SearchBar);

            // let selectValue = document.getElementById("exampleSelect").value;
           //     let inputValue = document.getElementById("searchValue").value;
          //      console.log('Your input value is: ', selectValue, inputValue);
         //       if (inputValue){
       // this.props.history.push(`/search/${selectValue} / ${inputValue} / 1`)
       // } else{
       // this.props.history.push(`/searchAll/${selectValue} / 1`)
       // } 
       // < /div>); 
       // } 

       // } */
        //send state to the server code

