/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import React from 'react';
import {
Collapse,
        Navbar,
        NavbarToggler,
        NavbarBrand,
        Nav,
        NavItem,
        UncontrolledDropdown,
        DropdownToggle,
        DropdownMenu,
        DropdownItem,Button } from 'reactstrap';
import SignIn from './SignIn.js';
import JoinUs from './JoinUs.js';


export default class Example extends React.Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            isOpen: false
        };
    }
    toggle() {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }
    render() {
        return (
<div>
    <Navbar color="dark" className  ="navbar-dark navbar-expand-sm" expand="md" size= "ml">
        <NavbarBrand href="/">HatBoxPhoto</NavbarBrand>
        <NavbarToggler onClick={this.toggle} />
        <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>

                <NavItem>
                   {/* <NavLink href="/"><Button color = "dark " size = "sm" >Sign In</Button></NavLink> */}
                    <SignIn/>

                </NavItem>
                <NavItem>               
                    <JoinUs/>
                </NavItem>
                
                <UncontrolledDropdown nav inNavbar>

                    <DropdownToggle nav caret>
                    <Button color = "dark" size = "sm" >More</Button>
                    </DropdownToggle>
                    <DropdownMenu  right>
                        <DropdownItem href="/About"> About </DropdownItem>
                        <DropdownItem > More </DropdownItem>
                    </DropdownMenu>

                </UncontrolledDropdown>
            </Nav>
        </Collapse>
    </Navbar>
</div>
        );
    }
}
