/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React from 'react';
import {BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom';
import {Container, Button, Row, Col} from 'reactstrap';
import Profile from './parts/Profile';
import Upload from './parts/Upload';
import adminHistory from './parts/adminHistory';
import userHome from './parts/userHome';
import adminMessage from './parts/adminMessage';

const style = {
    
    width: "60%",
    padding: '10px 20px' ,
    margin: '30px auto 30px auto ',
    textAlign: 'center',
    display: 'block',
    fontSize: '20px',
    overflow: 'hidden',
    linHheight: '30px',
    position: 'relative',
    color: 'white',
    borderRadius: '8px',
    backgroundColor: '#25A9E2'
    
};

export default class Admin extends React.Component {
        render(){
            return(
                    <div> 
                   
                    
                        <div style = {{ dispaly: "flex" ,float: 'left' ,width: '20%', height: '800px', background: 'lightgrey'}}> 
                                                           
                    <Row> <Button style = {style} href = '/admin' >  Home  </Button>  </Row>  
                    <Row> <Button style = {style} href = '/admin/profile' >  Profile  </Button> </Row>
                    <Row> <Button style = {style} href = '/admin/request' >  Request  </Button> </Row>
                    <Row> <Button style = {style} href = '/admin/message' disabled>  Message  </Button> </Row>
                    <Row> <Button style = {style} href = '/admin/history' disabled>  History  </Button> </Row>

                        </div>
            
                    <div style = {{ float:'right' ,width: '80%', height: '800px'}}>
                    <Switch>
                    
                        <Route exact path ='/admin' component = {userHome} />
                        <Route path ='/admin/profile' component = {Profile} />
                        <Route path ='/admin/request' component = {Request} />
                      {/*  <Route path ='/admin/message' component = {adminMessage} /> 
                        <Route path ='/admin/history' component = {adminHistory} /> */}
                        
                    </Switch>
                    </div>
                    
                    </div>
                    
                    
                    
                    
                    
                    )
        }
}