/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React from "react";


const style = {
    textAlign: 'center',
    width: '60%',
    margin: '250px auto 250px auto'
};

export default class home extends React.Component {
        
        
        
        render(){
            return(
                    
                    <div style = {style}>   
                    
                    <h2>Wecome to HatBoxPhoto!</h2>
                    
                    </div>
                    
                    
                    )
        }
}