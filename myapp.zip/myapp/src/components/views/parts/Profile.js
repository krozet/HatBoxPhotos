/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React from 'react';
import {Container, Col, Button,  FormGroup, Label, Input, FormText, Modal, ModalHeader, ModalBody, ModalFooter} from 'reactstrap';
import { AvForm, AvField, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';





export default class profile extends React.Component {
        constructor(props){
            
            super(props);
            this.state = {
                lastname: '',
                firstname: ' ',
                address:'',
                suite:'',
                city: '',
                state: '',
                zipcode: '',
                pwd:''
            }
            
            this.updateLast = this.updateLast.bind(this);
            this.updateFirst = this.updateFirst.bind(this);
            this.updateStreet = this.updateStreet.bind(this);
            this.updateSuite = this.updateSuite.bind(this);
            this.updateCity = this.updateCity.bind(this);
            this.updateState = this.updateState.bind(this);
            this.updateZip = this.updateZip.bind(this);     
            this.updateSave = this.updateSave.bind(this);
            this.checkCharater = this.checkCharater.bind(this);
            this.checkNumber = this.checkNumber.bind(this);
        }
        
        updateLast(event){
            this.setState({last: event.target.value});
        }
        updateFirst(event){
            this.setState({last: event.target.value});
        }
        updateStreet(event){
            this.setState({last: event.target.value});
        }
        updateSuite(event){
            this.setState({last: event.target.value});
        }
        updateCity(event){
            this.setState({last: event.target.value});
        }
        updateState(event){
            this.setState({last: event.target.value});
        }
        updateZip(event){
            this.setState({last: event.target.value});
        }
       
        updateSave(event){
            
        }
        componentDidMount(){
            //this will fetch data about user from back-end and display it 
        }
        
        checkCharater(event){
            const re = /[a-zA-Z ]+/g;
            if(!re.test(event.key)){
                event.preventDefault();
            }
        }
        checkNumber(event){
            const re = /[0-9]+/g;
            if(!re.test(event.key)){
                event.preventDefault();
            }
        }
        render(){
            return(
                    
                    <Container>
            
      <AvForm onSubmit = {this.updateSave}>
      <p></p>
        <AvGroup row>
          <Col ml={6}>
            <AvField label = "First Name" type="text" name="first" id="exampleFirst" placeholder="Ex: Sfsu" maxLength = '40' onKeyPress = {(e)=>this.checkCharater(e)} onChange = {this.updateFirst} />
            <FormText>Please enter characters only.</FormText>
          </Col>
          <Col sm={6}>
            <AvField label = "Last Name" type="text" name="last" id="exampleLast" placeholder="Ex: Sfsu" maxLength = '40' onKeyPress = {(e)=>this.checkCharater(e)} onChange = {this.updateLast} />
            <FormText>Please enter characters only.</FormText>
          </Col>
          
        </AvGroup>
        
        <FormGroup row >
        <Col sm={8}>
        <AvGroup>
          
            <AvField label = "Street" type="text" name="street" id="street" placeholder="Ex: 1600 Hollow Way" maxLength = '40'  onChange = {this.updateStreet} />
            <FormText>Please enter address.</FormText>
            </AvGroup>
          </Col>
          
          <Col sm={4}>
            <AvField label = "Suite" type="text" name="suite" id="suite" placeholder="Ex: Apt 308" maxLength = '40'  onChange = {this.updateSuite} />
        <FormText>Please enter suite.</FormText>     
          </Col>
          </FormGroup>

        
        
        <AvGroup row>
          <Col sm={5}>
            <AvField label = "City" type="text" name="city" id="exampleCity" placeholder="Ex: San Francisco" maxLength = '40' onKeyPress = {(e)=>this.checkCharater(e)} onChange = {this.updateCity} />
            <FormText>Please enter city.</FormText>
          </Col>
          
          <Col sm={4}>
            <AvField  label = "State" type="select" name="state" id="state"  maxLength = '40'  onChange = {this.updateState} >
            <option></option>
            
            <option>Alabama </option>
            <option>Alaska</option>
            <option>Arizona</option>
            <option>Arkansas</option>
            <option>California</option>
            <option>Colorado</option>
            <option>Connecticut</option>
            <option>Delaware</option>
            <option>Florida</option>
            <option>Georgia</option>
            <option>Hawaii</option>
            <option>Idaho</option>
            <option>Illinois</option>
            <option>Indiana</option>
            <option>Iowa</option>
            <option>Kansas</option>
            <option>Kentucky</option>
            <option>Louisiana</option>
            <option>Maine</option>
            <option>Maryland</option>
            <option>Massachusetts</option>
            <option>Michigan</option>
            <option>Minnesota</option>
            <option>Mississippi</option>
            <option>Missouri</option>
            <option>Montana</option>
            <option>Nebraska</option>
            <option>Nevada</option>
            <option>New Hampshire</option>
            <option>New Jersey</option>
            <option>New Mexico</option>
            <option>New York</option>
            <option>North Carolina</option>
            <option>North Dakota</option>
            <option>Ohio</option>
            <option>Oklahoma</option>
            <option>Oregon</option>
            <option>Pennsylvania</option>
            <option>Rhode Island</option>
            <option>South Carolina</option>
            <option>South Dakota</option>
            <option>Tennessee</option>
            <option>Texas</option>
            <option>Utah</option>
            <option>Vermont</option>
            <option>Virginia</option>
            <option>Washington</option>
            <option> West Virginia</option>
            <option>Wisconsin</option>
            <option>Wyoming</option>
            </AvField>
            <FormText>Please choose state.</FormText>
          </Col>
          <Col sm={3}>
            <AvField label= "Zip Code"type="text" name="zipcode" id="zipcode" placeholder="Ex: 94132" minLength ='5' maxLength = '5' onKeyPress = {(e)=>this.checkNumber(e)} onChange = {this.updateZip} />
            <FormText>Posstive 5 digits.</FormText>
          </Col>
        </AvGroup>
        
        
        <FormGroup row>    
          
          <Col sm={12}>
            <AvField label = "Email" type="text" name="email" id="email"  maxLength = '40'  disabled/>
               
            </Col>
          </FormGroup>
          
          <AvGroup row>    
          <Col >
            <AvField label = "Enter Password" type="password" name="password" id="password" placeholder ="Minlength 8 and Maxlength 20" minLength = '8' maxLength ='20' onChange = {this.updatePwd} />
            <FormText>Please enter password.</FormText>        
          </Col>
        </AvGroup>
        <AvGroup row>
          <Col >
            <AvField label = "Confirm Password" type="password" name="repassword" id="repassword" placeholder ="Re-type password" validate={{match:{value:'password'}}} />
            <FormText>Please re-enter the same password.</FormText>  
          </Col>
        </AvGroup>
          <FormGroup>
          <Col sm = {12}>
            <Button color = 'primary' size = "lg" block >Save</Button>
            </Col>        
        </FormGroup>
          </AvForm>
          </Container>
                    
                    
                    )
        }
        
}