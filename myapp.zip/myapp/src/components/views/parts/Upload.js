/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React from 'react';
import {Container, Col, Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
import { AvForm, AvField, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import axios from 'axios';
import Popup from 'reactjs-popup';
import {Redirect, withRouter} from 'react-router-dom';

const style = {
    marginLeft: 'auto',
    marginRight: 'auto'
};

class Upload extends React.Component {
        constructor(props){
            super(props);
            this.state = {
                category:'',
                des: '',
                comment: '',
                file: null,
                popup: false,
                redirect: false
                
            }
            
            this.updateTitle = this.updateTitle.bind(this);
            this.updateCategory = this.updateCategory.bind(this);
            this.updateDes = this.updateDes.bind(this);
            this.updateComment = this.updateComment.bind(this);
            this.updateFile= this.updateFile.bind(this);
            this.updateSubmit = this.updateSubmit(this);
            this.toggle = this.toggle.bind(this);
            this.setRedirect = this.setRedirect.bind(this);
            //this.renderRedirect = this.renderRedirect.bind(this);
            
        }
        
        updateTitle(event){
            this.setState({title: event.target.value});
        }
        updateCategory(event){
            this.setState({category: event.target.value});
        }
        updateDes(event){
            this.setState({des: event.target.value});
        }
        updateComment(event){
            this.setState({comment: event.target.value});
        }
        updateFile(event){
            this.setState({file: event.target.files});
        }
        setRedirect(){
            this.setState({redirect:true});
        }
        
        updateSubmit(){
            //event.preventDefault();
            
            //axios.post(url)
            //this.props.history.pop('/uploadimages');
            const fd = new FormData();
            fd.append('image',this.state.file,{image_category: this.state.category,             
                image_description: this.state.des,
                /*'image_comment': this.state.comment,*/
                uploaded_by: 'Arnold'});
            
            console.log(this.state.file);
            console.log(this.state.category);
            console.log(this.state.des);
            console.log("FormData", fd);
            
            axios.post(`https://hatboxphotos.com/images/`,fd)
                    .then(res => {
                        console.log("Upload image",res);
            }).then(err => {
                console.log("Error",err);
            })
            //this.props.history.push('/photographer/upload');
            //return <Redirect to ='/photographer/upload'/>
            if(this.state.category !== null && this.state.des !== null && this.state.file !== null){
                window.location.reload();
            }
            
        }
        
        toggle() {
            this.setState({
                popup: !this.state.popup
                });
        }
        
        render(){
            return(
                    <div>
                    
            <Container style = {style}>    
                    <AvForm onValidSubmit = {this.updateSubmit} style = {style}>
                    <p></p>
                    
       {/* <AvGroup >
        
        <Col sm = {12}>
          <AvField  label = "Title* (required)" type="text" name="title" id="titile" bgSize = 'lg' onChange = {this.updateTitle} required />
          <FormText>Please enter image title.</FormText>
          </Col>
        </AvGroup>*/}
        
            <AvGroup>
            <Col sm = {12} >
            <AvField label =" Category* (requried)" type ="select" name ="upload-category" id ="upload-category" onChange = {this.updateCategory} required >
            <option></option>
            <option>Nature</option>
            <option>Animal</option>
            <option>City</option>
            <option>Food</option>
            <option>Car</option>
            <option>Travel</option>
            
            </AvField>
            <FormText> Please choose image category.</FormText>
            </Col>
            
            </AvGroup>
            
        
        
        <AvGroup>
          
          <Col sm = {12}>
          <AvField label = "Description* (required)" type="textarea" name="description" id="drscription" onChange = {this.updateDes} required/>
          <FormText>Please enter image description.</FormText>
          </Col>
        </AvGroup>
        
        <AvGroup>
          
          <Col sm = {12}>
          <AvField label = "Comment" type="textarea" name="comment" id="comment" onChange = {this.updateComment}/>
          <FormText>Please enter comment about image.</FormText>
          </Col>
        </AvGroup>

        <AvGroup>
          
          <Col sm = {12}>
          <AvField label = "File* (required)" type="file" name="file" id="exampleFile" onChange = {this.updateFile} required />
          <FormText color="muted">
            Please choose the image you want to upload.
          </FormText>
          </Col>
        </AvGroup>
        <Col sm= {12}>
        <Button color = "primary" block>Submit</Button>
                {/*    <Popup 
                    trigger={<Button color = 'primary' block> Submit </Button>} 
                    modal 
                    lockScroll={false}
                    onClick = {this.toggle} >
                    {close => (
                    <div className = "text-center"><h4>Confirm submit please click Confirm. </h4>
                        <h4>Administrator will get back to you in 48 hours.</h4>
                        <h4> Otherwise, click on cancel. </h4>
                        
                        <div >
                            <Button style = {{width: '30%',marginLeft: '10%', marginRight:'10%' }} color = "danger" onClick = {()=>{close();}} > Cancel </Button>
                            <Button style = {{width: '30%', marginLeft: '10%', marginRight:'10%'}} color = "primary"  > Confirm</Button>   
                        </div> 
                    </div>
                    )}
            </Popup> */}
        </Col>
        
        
        
      </AvForm>
      
                    
                    
                    </Container>
                    
                    
                    
                    
                    
                    </div>
                    
                    
                    
                    
                    
                    
                    )
        }
};

export default withRouter(Upload);