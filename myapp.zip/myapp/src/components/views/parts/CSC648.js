/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global center */

import React from 'react';
import {Alert,Navbar} from 'reactstrap';
export default class CSC648 extends React.Component {
    render() {
        return (
                <div>
                    <Navbar color ="secondary" style = {{text: "center"}}>
                        <div className = "text-center">

                        SFSU Software Engineering Project CSC 648-848 Summer 2018 Summer 2018 For Demonstration Only

                       

                        </div>
                    </Navbar>
                </div>

                );
    }
}