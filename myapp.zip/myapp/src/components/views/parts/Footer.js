/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React, { Component } from 'react';





class foot extends Component {
    render() {
        return (
                <footer>
              <h6 className ="text-center"> Copyright 2018 SFSU CSC648 Team 5. All Rights Reversed. </h6>
                </footer>
            );
}
};

export default foot;