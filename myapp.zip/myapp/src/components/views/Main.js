/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import React from 'react';
import {Switch, Route} from 'react-router-dom';
import Home from './Home';
import About from './About';
import Search from './Search';
import SearchBar from './SearchBar';
import Photographer from './Photographer';
import Student from './Student';
import Admin from './Admin';
import axios from 'axios';


export default class Main extends React.Component {
    constructor(props) {
    super(props);
    console.log("Main");
    this.state = {
        selectInput : 'Nature',
        searchInput: ' ',
        search: false,
        pictures: [],
        strings: [],
        test: 'test',
        persons: []
              
    }

        this.updateSelectFromChild = this.updateSelectFromChild.bind(this);
        this.updateSearchFromChild = this.updateSearchFromChild.bind(this);
        this.updateSubmit = this.updateSubmit.bind(this);
    };
    
    updateSearchFromChild(searchInput){
        console.log("main updateSearchFromChild");
        console.log(searchInput);
        console.log(this.state.searchInput);
        console.log(this.state.search);
       // this.setState({searchInput, search:false});
        this.setState({searchInput:searchInput, search:false});
    }
    updateSelectFromChild(selectInput){
        this.setState({selectInput, search:false});
    }
    
    updateSubmit(){
        this.setState({search:true});
    }

    
    componentWillMount(){

      const select = this.state.selectInput;  
      const search = this.state.searchInput;
        console.log("main componentWillMount");
        console.log(select);
        console.log(search);

     /* axios.get(`https://hatboxphotos.com/images/`)
      .then(res => {
        const persons = res.data;
        console.log("data passing", res)
        this.setState({ persons });
      }).catch(error=>{
              console.log(error);
          })*/
    }
    render(){
        console.log('main render');
        console.log(this.state.searchInput);
    return(
        <div> 

    <SearchBar  selectInput = {this.state.selectInput} 
    searchInput = {this.state.searchInput}
    onChangeSelectInput = {this.updateSelectFromChild} 
    onChangeSearchInput={this.updateSearchFromChild}
    onSearchTermSubmit= {this.updateSubmit}/>



    {/*<div>{this.state.persons.map(Person =><li>{Person.name}</li>)}</div>
    <div>{this.state.test}</div>
    <div> <ul>
    {this.state.persons.map(person => <li>{person.name}</li>)}
            </ul>
            </div>    */}     
    <Switch>
    <Route exact path ='/' component = {Home} />
    <Route path ='/About'  component = {About} />   
    
    {/*Pass object searchInput, selectInput and search to render in Search component */}
    <Route path ='/Search' render={() => <Search searchInput = {this.state.searchInput} 
    selectInput = {this.state.selectInput} pictures = {this.state.pictures}
    strings = {this.state.persons} search = {this.state.search} page = {1}/> } />
    
            
    <Route path ='/SearchAll/:select/:page' component = {Search} />     
    <Route path ='/Search/:select/:input/:page' component = {Search} />
                      
                      
    <Route path ='/photographer' component = {Photographer} />
    <Route path ='/admin' component = {Admin} />
    <Route path ='/student' component = {Student} />
    </Switch> 
</div>

        )
}
}
