import React from 'react';
import { Button, Popover, PopoverHeader, PopoverBody } from 'reactstrap';
import SignInForm from './SignInForm.js';

export default class SignIn extends React.Component {
  constructor(props) {
    super(props);
    console.log(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      popoverOpen: false
    };
  }

  toggle() {
    this.setState({
      popoverOpen: !this.state.popoverOpen
    });
  }

  render() {
    return (
      <div>
      
       <Button id="Popover1" onClick={this.toggle}>
          Sign In
        </Button>
      
        <Popover placement="bottom" isOpen={this.state.popoverOpen} target="Popover1" toggle={this.toggle}>
          <PopoverHeader>Sign In</PopoverHeader>
          <PopoverBody><SignInForm>
          
           </SignInForm></PopoverBody>
        </Popover>
      </div>
    );
  }
}