
var express = require('express');
var renderToString = require('react-dom/server');
var React = require('react');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);
var users = require('./routes/UserAccountRouter');
var images = require("./routes/UploadedImageRouter");

const app = express();
const port = 8080;

// Connect mongoose to MongoDB database
const options = {
    autoReconnect: true,
    auth: {authdb: 'admin'},
user: 'admin',
pass: 'csc648root'
};

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Vary: Origin, X-Requested-With, Content-Type, Accept'
  );
  if (req.method === 'Options') {
    res.header('Access-Control-Allow-Methods', 'PUT, POST, DELETE');
    return res.status(200).json({});
  }
  next();
});

mongoose.Promise = global.Promise;
mongoose.connect("mongodb://hatboxphotos.com:27020/hatboxphotosDB", options);

// use this for testing post, so the db doesn't get overflooded
// mongoose.connect("mongodb://hatboxphotos.com:27020/testDB", options);

mongoose.connection.once('open', function () {
    console.log('Mongoose connection has been made!');
}).on('error', function (error) {
    console.log('Mongoose connection error:', error);
});
var db = mongoose.connection;

// //use sessions for tracking logins
app.use(session({
    secret: 'work hard',
    resave: true,
    saveUninitialized: false,
    store: new MongoStore({mongooseConnection: db})
    })
);

// Bind connection to error event
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {});

// parse incoming requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

// app.use(express.static("build"));

app.get("/", (req, res) => {
//  res.send('public/index.html', {root: __dirname})
    res.send('Express server running.');
    // res.send({type: 'GET'});
});

app.get("/service-worker.js", (req, res) => {
  res.sendFile(path.resolve(__dirname, "build", "service-worker.js"));
});

// include routes
app.use('/users', users);
app.use('/images', images);

app.listen(port, () => {
    console.log("Server is listening  to port: " + port);
});
