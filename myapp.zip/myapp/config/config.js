module.exports = {
    db: 'mongodb://krozet:csc648@hatboxphotos.com:27017/userDB'
};