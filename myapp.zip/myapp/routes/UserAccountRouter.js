/*
 * Test router for user authentication.
 */
var express = require('express');
var router = express.Router();

// Import registered user Model
var RegisteredUser = require('../models/UserAccount');

// GET route for reading data from login/registration page
// Path to test login page
router.get('/', function (req, res, next) {
  return res.sendFile(path.join(__dirname + '/templateLogReg/index.html'));
});

// POST route for sending data to the server
router.post('/', function (req, res, next) {
    // REGISTRATION route
    // Adds a new registered user to the registered users collection
    // after user enters all fields in registration form.
    if (req.body.email &&
        req.body.username &&
        req.body.password) {

        // Fields for account document from user input
        var userData = {
            email: req.body.email,
            username: req.body.username,
            password: req.body.password
        };

        // Creates an account document in registered users collection
        // with userData fields
        RegisteredUser.create(userData, function (error, user) {
          if (error) {
            return next(error);
          }
          // Navigate new registered user to their profile once registration
          // is complete.
          // This starts a session. SEE: SESSION ROUTE
          else {
            console.log("successfully created an account.");

            req.session.userId = user._id;
            return res.redirect('/photographer/profile');
          }
        });
    }

    // User LOGIN route
    else if (req.body.username && req.body.password) {
        // Checks if username and password entered by user
        // matches the username and password in the registered user database
        RegisteredUser.authenticate(req.body.username, req.body.password, function (error, user) {
            if (error || !user) {
                var err = new Error('Wrong username or password.');
                err.status = 401;
                return next(err);
            }
            // Redirect user to their profile if authentication was successful
            else {
              console.log("successfully logged in.");
                req.session.userId = user._id;
                return res.redirect('/photographer/profile');
            }
        });
    }
    else {
        var err = new Error('All fields required.');
        err.status = 400;
        return next(err);
    }
});

// GET route after registering
// SESSION ROUTE
router.get('/profile', function (req, res, next) {
  RegisteredUser.findById(req.session.userId).exec(function (error, user) {
      if (error) {
        return next(error);
      }
      else {
        if (user === null) {
          var err = new Error('Not authorized! Go back!');
          err.status = 400;
          return next(err);
        }

        // Note: this looks like user profile page. Perhaps front-end
        // can edit this
        else {
          return res.send('<h1>Name: </h1>' + user.username + '<h2>Mail: </h2>' + user.email + '<br><a type="button" href="/logout">Logout</a>');
        }
      }
    });
});

// GET route for logout
// Ends user session
router.get('/logout', function (req, res, next) {
  if (req.session) {
    // delete session object
    req.session.destroy(function (err) {
      if (err) {
        return next(err);
      }
      else {
        return res.redirect('/');
      }
    });
  }
});

module.exports = router;
